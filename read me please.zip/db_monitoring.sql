-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 15 Jul 2019 pada 18.51
-- Versi server: 10.3.16-MariaDB
-- Versi PHP: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_monitoring`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `dataagen`
--

CREATE TABLE `dataagen` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `idAgen` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `namaAgen` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamatAgen` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `latitude` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `longtitude` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `dataagen`
--

INSERT INTO `dataagen` (`id`, `idAgen`, `namaAgen`, `alamatAgen`, `username`, `password`, `latitude`, `longtitude`, `level`, `status`, `created_at`, `updated_at`) VALUES
(1, '100001', 'PT. Sarana Makmur Jaya Mandiri', 'Jl. Merpati Kota Tegal', '100000', '100000', '-6.881453340053253', '109.0856341620525', 'agen', 1, '2019-07-07 00:10:55', '2019-07-07 00:15:58'),
(3, '120000', 'Pt. Titik Kejenuhan', 'Jl. Merpati Kota Tegal', '120000', '120000', '-6.885554423403066', '109.1213524393305', 'agen', 0, '2019-07-07 00:13:28', '2019-07-07 00:16:07'),
(4, '123123', 'PT. Sejahtera Terus', 'Jl. Merpati Kota Tegal Lontrong 16', '123123', '123123', '-6.873421949225014', '109.09696784618882', 'agen', 1, '2019-07-09 01:25:15', '2019-07-09 01:25:15'),
(5, '122122', 'PT. Sarana Makmur Jaya', 'Jl. Merpati Kota Tegal', '122122', '122122', '-6.888117582497357', '109.07876526257597', 'agen', 1, '2019-07-09 02:52:56', '2019-07-09 02:52:56'),
(7, '111114', 'PT. Selalu Tegal', 'Jl. Merpati Kota Tegal Lontrong 16', '111114', '111114', '-6.879573665010317', '109.08460382713105', 'agen', 1, '2019-07-09 02:54:35', '2019-07-09 02:54:35'),
(8, '112211', 'PT. Erien Mandiri', 'Jl. Anoman', '112211', '112211', '-6.869149877526256', '109.09525062131966', 'agen', 1, '2019-07-09 23:33:59', '2019-07-09 23:33:59'),
(10, '112233', 'PT. Mercusuar Indah', 'Jl. Anoman', '112233', '112233', '-6.874789004060446', '109.11740282213148', 'agen', 1, '2019-07-09 23:39:13', '2019-07-09 23:39:13'),
(11, 'qwerty@gmail.com', 'Agus Hendro', 'Jl. Anoman', 'qwerty@gmail.com', 'qwerty@gmail.com', '-6.881095995953889', '109.0840349631521', 'agen', 1, '2019-07-12 21:53:16', '2019-07-12 21:53:16'),
(12, 'qwerty12@gmail.com', 'Selalu', 'purin', 'qwerty12@gmail.com', 'qwerty12@gmail.com', '-6.886890406752077', '109.08163235182822', 'agen', 1, '2019-07-12 21:56:17', '2019-07-12 21:56:17'),
(13, 'agen01@gmail.com', 'PT. Tegal Bahari', 'Jl. Merpati Kota Tegal Lontrong 16', 'agen01@gmail.com', 'agen01@gmail.com', '-6.884554410267263', '109.08610184678672', 'agen', 0, '2019-07-15 09:22:53', '2019-07-15 09:23:59');

-- --------------------------------------------------------

--
-- Struktur dari tabel `distribusi`
--

CREATE TABLE `distribusi` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `idAgen` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `namaPenyalur` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal` date NOT NULL,
  `realisasi` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `distribusi`
--

INSERT INTO `distribusi` (`id`, `idAgen`, `namaPenyalur`, `tanggal`, `realisasi`, `status`, `created_at`, `updated_at`) VALUES
(1, 'A00091', 'Ahmad Riyadi', '2019-07-04', 30, 0, '2019-07-06 22:01:12', '2019-07-06 23:21:36'),
(3, 'A90012', 'A76090', '2019-07-31', 50, 0, '2019-07-06 22:03:59', '2019-07-06 23:21:44'),
(4, 'A76090', 'A76090', '2019-07-11', 30, 1, '2019-07-06 22:17:16', '2019-07-06 22:17:16'),
(5, '100001', '100001', '2019-07-26', 500, 0, '2019-07-07 00:25:13', '2019-07-07 00:26:44'),
(6, '123123', 'qwerty12@gmail.com', '2019-07-04', 60, 1, '2019-07-15 09:33:31', '2019-07-15 09:33:31');

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_07_01_233409_create_agen_table', 1),
(2, '2019_07_02_182439_table_agens', 2),
(3, '2019_07_04_071342_create_table_siswa', 3),
(4, '2019_07_04_085526_create_table_login', 3),
(5, '2019_07_04_164227_create_agen', 4),
(6, '2019_07_06_012728_create_penyalur', 5),
(7, '2019_07_06_013637_create_penyalur', 6),
(8, '2019_07_06_014218_create_penyalur', 7),
(9, '2019_07_07_034011_create_distribusi', 8),
(10, '2019_07_07_041749_create_distribusi', 9),
(11, '2019_07_07_070121_create_data_agen', 10),
(12, '2019_07_07_070427_create_user', 10),
(13, '2019_07_09_081517_create_table_users', 11);

-- --------------------------------------------------------

--
-- Struktur dari tabel `penyalur`
--

CREATE TABLE `penyalur` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `idAgen` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idPenyalur` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `namaPenyalur` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamatPenyalur` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `kuota` int(11) NOT NULL,
  `latitude` varchar(225) COLLATE utf8mb4_unicode_ci NOT NULL,
  `longtitude` varchar(225) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `penyalur`
--

INSERT INTO `penyalur` (`id`, `idAgen`, `idPenyalur`, `namaPenyalur`, `alamatPenyalur`, `kuota`, `latitude`, `longtitude`, `status`, `created_at`, `updated_at`) VALUES
(1, '231131', 'P12121', 'Ahmad Riyadi', 'Jl. Kartini', 50, '-7', '109', 0, '2019-07-05 20:35:01', '2019-07-06 19:51:59'),
(2, '112312', 'P12122', 'Ahmad Slamet Riyadi', 'Jl. Kartini Utara No.23', 50, '-7', '109', 1, '2019-07-05 20:41:28', '2019-07-05 20:41:28'),
(3, 'A76090', 'P12123', 'Riyadi Ahmad', 'Jl. Kartini', 50, '-7', '109', 0, '2019-07-06 20:04:49', '2019-07-07 00:19:18'),
(4, '100001', 'P11000', 'Rezaldi Hehanusa', 'Jl. Kartini Barat', 100, '-7', '109', 0, '2019-07-07 00:18:33', '2019-07-07 00:21:56'),
(5, '100001', 'P11011', 'Rezaldi Hehanusa Atmajaya', 'Jl. Kartini Utara No.231', 50, '-7', '109', 1, '2019-07-07 00:21:23', '2019-07-07 00:21:23'),
(6, '123341', '100', 'GonzalesHehanusa Atmajaya', 'Jl. Kartini', 58, '-7', '109', 1, '2019-07-08 00:32:12', '2019-07-08 01:19:25'),
(7, '112233', 'P12126', 'Sutarno', 'Jl. Kakap', 100, '-7', '109', 1, '2019-07-10 00:04:44', '2019-07-10 00:04:44');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `nama`, `email`, `password`, `level`, `status`, `created_at`, `updated_at`) VALUES
(1, 'PT. Sejahtera Terus', '123123@oke.com', '123123', 'agen', 1, '2019-07-09 01:25:15', '2019-07-09 01:25:15'),
(2, 'PT. Selalu Tegal', '111114', '$2y$10$Ip3SSyECQMOE6y75xb1NSOsLdhebgFymq/eN81kd17YHCMMGWUHVa', 'agen', 1, '2019-07-09 02:54:36', '2019-07-09 02:54:36'),
(3, 'PT. Erien Mandiri', '112211', '$2y$10$ylpMxz7nw211FcMH31k1Lu0iarANnvV1wG99q/IQyqIe1/wLROamO', 'agen', 1, '2019-07-09 23:34:00', '2019-07-09 23:34:00'),
(4, 'PT. Mercusuar Indah', '112233', '$2y$10$ajJ5cnPqgfbJxGN6HR/mzOWBLD7aJtsHSxqK2Z3A1JrBQ7dA8eWL6', 'agen', 1, '2019-07-09 23:36:30', '2019-07-09 23:36:30'),
(5, 'PT. Mercusuar Indah', '112233', '$2y$10$zC0CQmmRlR9SrZjgKBU11OuTeFoxG0S3b4CG7Ctd/kTck1C1gTLn.', 'agen', 1, '2019-07-09 23:39:14', '2019-07-09 23:39:14'),
(6, 'Agus Hendro', 'qwerty@gmail.com', '$2y$10$DAWOkUu68J/F/VoavsNjEeQDysQ/.XXdNeNXkKpQmsyyVwcTEZKy.', 'agen', 1, '2019-07-12 21:53:16', '2019-07-12 21:53:16'),
(7, 'Selalu', 'qwerty12@gmail.com', '$2y$10$LinUzXLPQIptz/nEnd7/J.gRr8zLCgN5N19EWEfSDyiq4S1SBNdOG', 'agen', 1, '2019-07-12 21:56:17', '2019-07-12 21:56:17'),
(8, 'Admin', 'adminbaru', '$2y$10$FY10Ixfxu28QE43yNgpKz.ckvfocQ6MzrRftKRAsG5K3YPNkNlXHq', 'admin', 1, '2019-07-15 08:42:15', '2019-07-15 08:42:15'),
(9, 'PT. Tegal Bahari', 'agen01@gmail.com', '$2y$10$tjuhFvtgT7qz7bQHLr3kAu7B/lO1bXgbiMdWOS2cRVyt1ZjELPTVi', 'agen', 1, '2019-07-15 09:22:54', '2019-07-15 09:22:54');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `dataagen`
--
ALTER TABLE `dataagen`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `dataagen_idagen_unique` (`idAgen`);

--
-- Indeks untuk tabel `distribusi`
--
ALTER TABLE `distribusi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `penyalur`
--
ALTER TABLE `penyalur`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `penyalur_idpenyalur_unique` (`idPenyalur`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `dataagen`
--
ALTER TABLE `dataagen`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `distribusi`
--
ALTER TABLE `distribusi`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `penyalur`
--
ALTER TABLE `penyalur`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
